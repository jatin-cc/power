import { apiFetch } from './apiClient.js';
import { normalizeProject } from '../utils/helpers.js';

const PROJECTS_URL = 'https://vlionserver.in/ini-work/public/work/v1/api/';
const PROJECT_DETAIL_URL = 'https://vlionserver.in/ini-work/public/project-view/v1/api/';

/**
 * Fetch paginated project list.
 * @param {number} page - Page number (default 1)
 * @param {AbortSignal} signal
 */
export async function getProjects(page = 1, signal) {
  const url = `${PROJECTS_URL}?page=${page}`;
  const data = await apiFetch(url, signal);
  const pagination = data.projects || {};
  return {
    projects: (pagination.data || []).map(normalizeProject),
    currentPage: pagination.current_page || 1,
    lastPage: pagination.last_page || 1,
    total: pagination.total || 0,
  };
}

/**
 * Fetch ALL projects across all pages.
 * @param {AbortSignal} signal
 */
export async function getAllProjects(signal) {
  const firstPage = await getProjects(1, signal);
  if (firstPage.lastPage === 1) return firstPage.projects;

  const promises = [];
  for (let p = 2; p <= firstPage.lastPage; p++) {
    promises.push(getProjects(p, signal));
  }
  const rest = await Promise.all(promises);
  return [
    ...firstPage.projects,
    ...rest.flatMap((r) => r.projects),
  ];
}

/**
 * Fetch a single project by ID.
 * @param {number|string} id
 * @param {AbortSignal} signal
 */
export async function getProjectById(id, signal) {
  if (!id) throw new Error('Project ID is required');
  const url = `${PROJECT_DETAIL_URL}?project=${id}`;
  const data = await apiFetch(url, signal);
  const raw = data.project || data.data || data;
  if (!raw || !raw.id) throw new Error('Project not found');
  return normalizeProject(raw);
}
