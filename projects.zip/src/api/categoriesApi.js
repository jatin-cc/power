import { apiFetch } from './apiClient.js';

const CATEGORIES_URL = 'https://vlionserver.in/ini-work/public/categories/v1/api/';

/**
 * Normalize a raw category from the API.
 */
function normalizeCategory(raw) {
  return {
    id: raw.id,
    parentId: raw.parent_id,
    name: raw.name,
    status: raw.status,
    children: (raw.children_recursive || []).map(normalizeCategory),
  };
}

/**
 * Fetch all categories from the API.
 * Returns a tree structure with parent categories and their children.
 */
export async function getCategories(signal) {
  const data = await apiFetch(CATEGORIES_URL, signal);
  const raw = data.categories || [];
  return raw.map(normalizeCategory);
}
